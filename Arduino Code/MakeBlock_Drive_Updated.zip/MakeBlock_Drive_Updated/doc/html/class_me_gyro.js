var class_me_gyro =
[
    [ "MeGyro", "class_me_gyro.html#a4a6b3f7485716b1943e15eb554b51ae7", null ],
    [ "MeGyro", "class_me_gyro.html#a207095ed46ba017c930c4fefe856828e", null ],
    [ "MeGyro", "class_me_gyro.html#a0340b5dfd830cbfc25034a3277ad071f", null ],
    [ "begin", "class_me_gyro.html#ae12dbf32cc840e0d734dc813d1d3b8cc", null ],
    [ "fast_update", "class_me_gyro.html#a01ab455745beef2583a64e83c88e54e0", null ],
    [ "getAngle", "class_me_gyro.html#a7ff55cc89d2507d47d193d659341b6b2", null ],
    [ "getAngleX", "class_me_gyro.html#a22f9944d93ab6c8b3c09195fcf002675", null ],
    [ "getAngleY", "class_me_gyro.html#a32858bdbdbc045d5885c8294d811c351", null ],
    [ "getAngleZ", "class_me_gyro.html#aee097463680345da15710d7e2f5bad04", null ],
    [ "getDevAddr", "class_me_gyro.html#a15122f1ff89422a7aa0f0bb0a7af82ad", null ],
    [ "getGyroX", "class_me_gyro.html#acd4874b1d99d4a79c4194b5f0a2691d1", null ],
    [ "getGyroY", "class_me_gyro.html#a2409cc23fd683a3f546f1660da49bf8d", null ],
    [ "getGyroZ", "class_me_gyro.html#a973d074ad4c72fec8bf77a43db27da06", null ],
    [ "resetData", "class_me_gyro.html#a1a7b23e100b983b19b83ff78f4a66af0", null ],
    [ "setpin", "class_me_gyro.html#ac183cec71c6d840b7c5d651d025e02ca", null ],
    [ "update", "class_me_gyro.html#a85373ad8f4764f9ab9cd0d880fb8dd19", null ]
];