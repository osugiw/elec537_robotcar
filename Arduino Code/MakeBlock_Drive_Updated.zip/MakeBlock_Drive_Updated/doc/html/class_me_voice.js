var class_me_voice =
[
    [ "MeVoice", "class_me_voice.html#af9c1752c4d82263049f676b31ffb2438", null ],
    [ "MeVoice", "class_me_voice.html#a4eaae4a750179d7132dc533a80e749b1", null ],
    [ "begin", "class_me_voice.html#a54a988d062a82fa0514a2c268043bf7c", null ],
    [ "getCode", "class_me_voice.html#a0ea6a575219b569d2c093cf50838e30b", null ],
    [ "loop", "class_me_voice.html#ae31f0be6411947ecef97104bf26bf646", null ],
    [ "read", "class_me_voice.html#a8e03afa2722be68289d8e5d7963935e9", null ]
];