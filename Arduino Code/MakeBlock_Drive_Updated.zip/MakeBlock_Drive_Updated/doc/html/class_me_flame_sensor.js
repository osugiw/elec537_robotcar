var class_me_flame_sensor =
[
    [ "MeFlameSensor", "class_me_flame_sensor.html#adc284c980be43010a9dc046ed9ecf03f", null ],
    [ "MeFlameSensor", "class_me_flame_sensor.html#a32ce1598a172c6ddd56b51713add39e3", null ],
    [ "readAnalog", "class_me_flame_sensor.html#a09baccd24c256f1ad1b59e148f43450a", null ],
    [ "readDigital", "class_me_flame_sensor.html#a01b134562c8fff15c7f7f48e18839cd0", null ],
    [ "setpin", "class_me_flame_sensor.html#a42b0282962ea9afea2d2b0d4bbdb1ce4", null ]
];