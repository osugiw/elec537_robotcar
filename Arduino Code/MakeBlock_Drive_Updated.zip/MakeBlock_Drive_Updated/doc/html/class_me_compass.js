var class_me_compass =
[
    [ "MeCompass", "class_me_compass.html#a2713d01cf20bac751fa1ac0d5ac0e00c", null ],
    [ "MeCompass", "class_me_compass.html#af6727a5bdba3f2042adeec5d5a61285d", null ],
    [ "MeCompass", "class_me_compass.html#ab15cfe4fdf45cc69008bef9cf39f4abf", null ],
    [ "begin", "class_me_compass.html#aa514632f78e2095ee341e146789cc6b3", null ],
    [ "getAngle", "class_me_compass.html#a544592a96b717dfd4d7f7357d22440a6", null ],
    [ "getHeading", "class_me_compass.html#a151c87c12cdcf667faf5f307bae8e418", null ],
    [ "getHeadingX", "class_me_compass.html#a968a8f7bc7534fefc8aad19b56472be4", null ],
    [ "getHeadingY", "class_me_compass.html#a39e81714f6c14f8dcc0faec9330eaa2c", null ],
    [ "getHeadingZ", "class_me_compass.html#ae0cb31dcc67e6a1f25292edd9506046d", null ],
    [ "setpin", "class_me_compass.html#acb63b0ff0fdfb216718b827f66f2915e", null ],
    [ "testConnection", "class_me_compass.html#a20480fba91e33e557ffb210ff06681d6", null ]
];