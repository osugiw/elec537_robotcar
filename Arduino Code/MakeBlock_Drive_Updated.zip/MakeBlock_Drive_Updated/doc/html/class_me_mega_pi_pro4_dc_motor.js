var class_me_mega_pi_pro4_dc_motor =
[
    [ "MeMegaPiPro4DcMotor", "class_me_mega_pi_pro4_dc_motor.html#a82a9c5416fb71a07550902f6dca71119", null ],
    [ "MeMegaPiPro4DcMotor", "class_me_mega_pi_pro4_dc_motor.html#a0797022589246f44bbbc7fd0d0467726", null ],
    [ "reset", "class_me_mega_pi_pro4_dc_motor.html#a4e6b8c161cfe6367a1c43f9b129a8597", null ],
    [ "reset", "class_me_mega_pi_pro4_dc_motor.html#a8ebf2a564ca4f4ec2458d472bd4ed9f8", null ],
    [ "run", "class_me_mega_pi_pro4_dc_motor.html#aa38cacfe02e74049f0b5b2ffa397676e", null ],
    [ "setpin", "class_me_mega_pi_pro4_dc_motor.html#a7dedce5958822fbb8c28bb5867357c80", null ],
    [ "stop", "class_me_mega_pi_pro4_dc_motor.html#afd87d1eda99dbde9a1a2223777b9b520", null ]
];