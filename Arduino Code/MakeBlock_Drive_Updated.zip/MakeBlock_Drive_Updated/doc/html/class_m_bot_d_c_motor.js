var class_m_bot_d_c_motor =
[
    [ "MBotDCMotor", "class_m_bot_d_c_motor.html#ab2b0796707235c4c87656ac986906b9a", null ],
    [ "move", "class_m_bot_d_c_motor.html#afe0b361462f7660fd767cd7e5a23ea77", null ]
];